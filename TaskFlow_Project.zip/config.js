//  TaskFlow — Google API Config
//  Add your own API keys here to enable Google Calendar sync


var TASKFLOW_CONFIG = {
  GCAL_CLIENT_ID: "",
  GCAL_API_KEY:   "",

  // OAuth scope — read+write so tasks sync to Google Calendar
  GCAL_SCOPES: "https://www.googleapis.com/auth/calendar"
};